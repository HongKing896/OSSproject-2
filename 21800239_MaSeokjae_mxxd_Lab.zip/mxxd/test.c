#include <stdio.h>

int main(int argc, char ** argv) {
    char input[30];
    scanf("%s", input);
    printf("My input => %s\n", input);
}